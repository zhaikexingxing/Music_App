package com.music.qichaoqun.music.bean;

public class MusicPauseOrStartMessage {
}
