package com.music.qichaoqun.music.BaseClass;

import android.graphics.Bitmap;

public interface ToBitmap{
    void getBitmap(Bitmap bitmap);
}
