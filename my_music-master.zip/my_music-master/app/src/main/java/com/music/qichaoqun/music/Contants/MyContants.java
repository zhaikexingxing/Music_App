package com.music.qichaoqun.music.Contants;

public class MyContants{
    public static final String MUSIC_PLAY = "com.qichaoqun.music.play";
    public static final String MUSIC_ERROR = "com.qichaoqun.music.error";
    public static final String MUSIC_UPDATE = "com.qichaoqun.music.update";
    public static final String NET_MUSIC_PLAY = "com.qichaoqun.music.net.play";
    public static final String NET_MUSIC_SONGS = "com.qichaoqun.music.net.songs";
    public static final String NEXT_PLAY = "com.qichaoqun.music.next_play";
    public static final String LAST_PLAY = "com.qichaoqun.music.last_play";
    public static final String MUSIC_INFO = "com.qichaoqun.music.info";
    public static final String MUSIC_PAUSE_START = "com.qichaoqun.start.pause";
    public static final String MUSIC_PAUSE_START_TWO = "com.qichaoqun.start.pause.two";
    public static final String MUSIC_UPDATE_SECOND = "com.qichaoqun.updata.second";
}